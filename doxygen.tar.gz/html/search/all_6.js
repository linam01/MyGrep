var searchData=
[
  ['main_2ec',['main.c',['../main_8c.html',1,'']]],
  ['motifs',['motifs',['../structoption__g.html#afe3347664e8c51ec477757a2e09ca610',1,'option_g']]]
];
