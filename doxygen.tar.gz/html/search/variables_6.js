var searchData=
[
  ['motifs',['motifs',['../structoption__g.html#afe3347664e8c51ec477757a2e09ca610',1,'option_g']]]
];
