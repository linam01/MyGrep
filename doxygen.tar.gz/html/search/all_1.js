var searchData=
[
  ['b_5fflag',['B_flag',['../structoption__g.html#a956dcf83c3bffc451db209de1b05ddbf',1,'option_g']]]
];
