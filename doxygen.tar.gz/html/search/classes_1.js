var searchData=
[
  ['stringlist',['StringList',['../structStringList.html',1,'']]]
];
