var searchData=
[
  ['recherche_5fdans_5fligne',['recherche_dans_ligne',['../recherche_8c.html#ae319a9c9eb91074717a7eb71b1a88456',1,'recherche_dans_ligne(char *ligne, StringList *motifs, bool ignore_case):&#160;recherche.c'],['../recherche_8h.html#ae319a9c9eb91074717a7eb71b1a88456',1,'recherche_dans_ligne(char *ligne, StringList *motifs, bool ignore_case):&#160;recherche.c']]],
  ['recherche_5ffichier',['recherche_fichier',['../recherche_8c.html#ae65c478f139be70f6a2a7e5bf499a940',1,'recherche_fichier(StringList *motifs, char *nom_fichier, option_g option):&#160;recherche.c'],['../recherche_8h.html#ae65c478f139be70f6a2a7e5bf499a940',1,'recherche_fichier(StringList *motifs, char *nom_fichier, option_g option):&#160;recherche.c']]],
  ['recherche_5fmotif',['recherche_motif',['../recherche_8c.html#a8e42fca571b4c514ea61867bfa247d05',1,'recherche_motif(StringList *motifs, FILE *fichier, option_g option, char *prefixe):&#160;recherche.c'],['../recherche_8h.html#a8e42fca571b4c514ea61867bfa247d05',1,'recherche_motif(StringList *motifs, FILE *fichier, option_g option, char *prefixe):&#160;recherche.c']]]
];
