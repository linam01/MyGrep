var searchData=
[
  ['l_5fflag',['l_flag',['../structoption__g.html#ad92d5d02dc08830754c8dbdd1f89adf5',1,'option_g::l_flag()'],['../structoption__g.html#ac6f984721e17b303f12ee06e906f30c4',1,'option_g::L_flag()']]]
];
