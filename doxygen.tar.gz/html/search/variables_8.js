var searchData=
[
  ['v_5fflag',['v_flag',['../structoption__g.html#aef9487670a50d149b6dd8c0b19821a98',1,'option_g']]]
];
