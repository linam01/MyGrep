var searchData=
[
  ['i_5fflag',['i_flag',['../structoption__g.html#a9f8ba20537dfc164c8d536a5e9955a57',1,'option_g']]],
  ['items',['items',['../structStringList.html#af52530ae55dd94fe9cba4aff023992ac',1,'StringList']]]
];
