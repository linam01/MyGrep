var searchData=
[
  ['n_5fflag',['n_flag',['../structoption__g.html#a3c6a5f8872bc57c025192e33da556a43',1,'option_g']]]
];
